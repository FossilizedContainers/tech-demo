from setuptools import setup

setup(
    name='presto',
    version='0.0.1',
    packages=[''],
    install_requires=[
        'Click',
        'Docker',
    ],
)